<?php

$term = "Fall";
$year = 2019;

$mainLocation = "/Course-Registration-System/web/";
#$mainLocation = "/dbms/";
$loglogin="okan";
$passpassword="okan123";

#--------------------------#

$sn = "167.71.66.201"; #servername
$un = "kole"; #username
$pss = "Scrool12*"; #password
$db = "471DB"; #database

?>
